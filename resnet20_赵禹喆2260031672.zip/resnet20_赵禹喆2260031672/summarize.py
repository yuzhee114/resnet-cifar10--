"""Aggregate only completed full baseline runs; never accept synthetic/pilot results."""
import argparse
import csv
import json
import statistics
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--results', default='results')
a = p.parse_args()
runs = []
for directory in sorted(Path(a.results).glob('resnet20_baseline_seed*')):
    if not (directory/'summary.json').exists():
        continue
    config = json.loads((directory/'config.json').read_text())
    summary = json.loads((directory/'summary.json').read_text())
    if summary['status'] != 'complete' or summary['final_step'] != 64000 or config['steps'] != 64000:
        continue
    if config['smoke'] or config['no_augmentation'] or config['batch_size'] != 128:
        continue
    runs.append((directory, config, summary))
if len(runs) < 3:
    raise SystemExit(f'Only {len(runs)} full runs; need at least 3. No scientific summary generated.')
if len({c['seed'] for _, c, _ in runs}) != len(runs):
    raise SystemExit('Duplicate random seeds')
keys = ['arch', 'steps', 'batch_size', 'normalization', 'torch', 'torchvision', 'device_used', 'script_sha256', 'upstream']
for key in keys:
    if len({json.dumps(c[key], sort_keys=True) for _, c, _ in runs}) != 1:
        raise SystemExit(f'Inconsistent run configuration: {key}')
errors = [s['test_error_pct'] for _, _, s in runs]
mean, std = statistics.mean(errors), statistics.stdev(errors)
output = Path(a.results)
with (output/'paper_vs_ours.csv').open('w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['model', 'paper_error_pct', 'ours_mean_error_pct', 'ours_sample_sd_pct', 'absolute_gap_percentage_points', 'relative_gap_pct', 'number_of_seeds'])
    w.writerow(['ResNet-20', 8.75, mean, std, mean-8.75, (mean-8.75)/8.75*100, len(runs)])
with (output/'traceability.csv').open('w', newline='') as f:
    w = csv.writer(f)
    w.writerow(['seed', 'test_error_pct', 'summary', 'metrics', 'config'])
    for directory, c, s in runs:
        with (directory/'metrics.csv').open() as log:
            last = list(csv.DictReader(log))[-1]
        if int(last['step']) != 64000 or abs(float(last['test_error_pct'])-s['test_error_pct']) > 1e-8:
            raise SystemExit('Summary does not match final metrics row')
        w.writerow([c['seed'], s['test_error_pct'], directory/'summary.json', directory/'metrics.csv', directory/'config.json'])
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(7, 4))
for directory, c, _ in runs:
    with (directory/'metrics.csv').open() as f:
        rows = list(csv.DictReader(f))
    ax.plot([int(r['step']) for r in rows], [float(r['test_error_pct']) for r in rows], label=f"seed {c['seed']}")
ax.set(xlabel='Optimization step', ylabel='Test error (%)', title='ResNet-20 / CIFAR-10')
ax.legend()
fig.tight_layout()
fig.savefig(output/'test_error_curves.png', dpi=180)
print(f'{mean:.4f} ± {std:.4f}% (sample SD, n={len(runs)}); paper 8.75%.')
