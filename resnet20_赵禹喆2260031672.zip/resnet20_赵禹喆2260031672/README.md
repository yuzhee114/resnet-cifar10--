# A 部分：ResNet-20 / CIFAR-10 基准复现

本周已完成真实 CIFAR-10 的 100 步短测。实验配置、结果和组内分工见[周提交记录](docs/2026-11-07_A_Weekly_Progress.md)。

## 环境

推荐 Python 3.11/3.12、Colab GPU。项目附带一个完整运行入口，可与B/C共用。

```sh
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/prepare.py
python train.py --seed 0 --smoke --device cpu
```

若已在 Colab 中，不必建虚拟环境；把完整项目文件夹放到运行环境并切换到该文件夹。安装依赖后若提示重启运行时，应重启再运行。固定依赖目标需在实际目标设备再次验证，实际环境版本也会写入每次运行的 config.json；本机验证环境另存 requirements-local-lock.txt。

## 正式实验

```sh
sh scripts/run_three.sh
```

三个种子依次运行，每个64000次参数更新，batch size 128，SGD，初始学习率0.1，32000/48000次更新后各降低10倍，momentum 0.9，weight decay 0.0001。使用全部50000张训练图和10000张测试图；不加载预训练权重。测试集只用于固定间隔监测和最终指标，不据此选择最优检查点。最终步的测试错误率为主指标。

先用真实数据计时：

```sh
python train.py --seed 0 --pilot --output results_pilot
```

pilot是计时测试，不能用于正式结果。短测的 summary.json 分别记录训练和评估耗时。以训练耗时乘640，再加上正式运行的64次评估耗时，可粗估同设备上单种子的耗时；首次运行开销会影响估算。正式训练过程不支持中途恢复；请使用稳定、可持续的GPU环境。Colab免费运行时可能不足以连续完成，先确认时长。不要把不同训练预算的结果混进正式统计。

## 输出

- results/resnet20_baseline_seedN/config.json：参数、版本、设备、代码哈希和参考代码commit。
- metrics.csv：每次评估的训练/测试指标。训练指标是最近窗口内、训练模式及增强数据上的统计，不能直接当论文评估模式训练误差。
- summary.json：仅正常完成才写入。
- checkpoints/：最终权重，本地保留，禁止推送。
- python summarize.py：只有至少3个不同种子的64000步完整实验才能输出均值、样本标准差、Paper vs. Ours对照表、追溯表和测试曲线。

合成数据smoke只检查前向、反向、写日志，不衡量识别能力。不会被汇总脚本当作研究结果。

## 给B、C的接口

B：同样的种子、相同训练预算，增加 --arch resnet56。C：同样的ResNet-20实验，只增加 --no-augmentation。所有人使用同一份upstream.json和同一训练脚本；若改公共配置，应先同步并记录差异。C的对比只允许改变增强这一因素。

## 来源与许可

课程指定参考仓库：https://github.com/akamaster/pytorch_resnet_cifar10
模型代码作者：Yerlan Idelbayev；许可保存在 UPSTREAM_LICENSE。
固定起点：d5489e8995e81e91ce6b1d69dcc98ad579b0b153。
模型源文件不修改；训练与统计程序为本项目新增。prepare.py下载固定版本，不能只使用不断变化的master。
论文：https://arxiv.org/abs/1512.03385 ，Section 4.2、Table 6、Figure 6。

如果自动下载过慢，可使用已下载的原始 CIFAR-10 Python 压缩包。下面的命令会先核对 torchvision 预期的 MD5，匹配才放入 data 目录；之后训练程序直接解包并检查数据文件。

```sh
python scripts/stage_cifar10.py /path/to/cifar-10-python.tar.gz --source '实际下载地址'
python train.py --seed 0 --pilot --output results_pilot
```

`pilot_only` 表示流程验证完成，不能拿该错误率与论文 Table 6 对比。请保留配置、日志和摘要作为周检查证据；不要提交数据压缩包或权重。
