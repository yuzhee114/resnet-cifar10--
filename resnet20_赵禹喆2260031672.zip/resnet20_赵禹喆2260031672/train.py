"""CIFAR-10 reproduction runner; upstream model is used without modification."""
import argparse
import csv
import hashlib
import json
import os
import platform
import random
import subprocess
import sys
import time
from pathlib import Path


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--seed', type=int, required=True)
    p.add_argument('--arch', choices=['resnet20', 'resnet56'], default='resnet20')
    p.add_argument('--steps', type=int, default=64000)
    p.add_argument('--batch-size', type=int, default=128)
    p.add_argument('--eval-every', type=int, default=1000)
    p.add_argument('--device', choices=['auto', 'cpu', 'cuda', 'mps'], default='auto')
    p.add_argument('--no-augmentation', action='store_true')
    p.add_argument('--pilot', action='store_true', help='100-update real-data check, excluded from formal results')
    p.add_argument('--smoke', action='store_true', help='Synthetic data pipeline check; NOT research results')
    p.add_argument('--output', default='results')
    p.add_argument('--data', default='data')
    a = p.parse_args()
    if min(a.steps, a.batch_size, a.eval_every) <= 0:
        p.error('steps, batch-size and eval-every must be positive')
    if a.pilot and a.smoke:
        p.error('--pilot uses real data and cannot be combined with --smoke')
    if a.pilot:
        a.steps, a.eval_every = 100, 50
    run_type = 'smoke' if a.smoke else 'pilot' if a.steps != 64000 or a.pilot else 'formal'
    import certifi
    os.environ.setdefault("SSL_CERT_FILE", certifi.where())
    import numpy as np
    import torch
    import torchvision
    from torch import nn
    from torch.utils.data import DataLoader, TensorDataset
    from torchvision import datasets, transforms
    root = Path(__file__).resolve().parent
    vendor = root / 'vendor' / 'pytorch_resnet_cifar10'
    if not (root / 'upstream.json').exists():
        raise SystemExit('Run python scripts/prepare.py first.')
    upstream = json.loads((root / 'upstream.json').read_text())
    sha = subprocess.check_output(['git', '-C', str(vendor), 'rev-parse', 'HEAD'], text=True).strip()
    if sha != upstream['commit']:
        raise SystemExit('Upstream revision does not match upstream.json')
    if subprocess.check_output(['git', '-C', str(vendor), 'status', '--porcelain', '--untracked-files=no'], text=True).strip():
        raise SystemExit('Upstream working tree is modified; restore it or document modifications first.')
    sys.path.insert(0, str(vendor))
    import resnet
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
    random.seed(a.seed)
    np.random.seed(a.seed)
    torch.manual_seed(a.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(a.seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)
    device = a.device
    if device == 'auto':
        device = 'cuda' if torch.cuda.is_available() else ('mps' if torch.backends.mps.is_available() else 'cpu')
    out = Path(a.output) / f'{a.arch}_{"smoke" if a.smoke else "pilot" if run_type == "pilot" else "noaug" if a.no_augmentation else "baseline"}_seed{a.seed}'
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'config.json').exists():
        raise SystemExit(f'{out} already contains a run; use a different --output to preserve evidence.')
    print(f'{run_type}: {a.arch}, seed={a.seed}, device={device}', flush=True)
    if a.smoke:
        a.steps = 2
        a.eval_every = 1
        ds = TensorDataset(torch.randn(32, 3, 32, 32), torch.randint(0, 10, (32,)))
        train_data = test_data = ds
    else:
        # Match the paper's per-pixel training mean subtraction (no channel std scaling).
        data_path = Path(a.data)
        archive = data_path / datasets.CIFAR10.filename
        if not (data_path / datasets.CIFAR10.base_folder).is_dir() and archive.is_file():
            from torchvision.datasets.utils import check_integrity, extract_archive
            if check_integrity(str(archive), datasets.CIFAR10.tgz_md5):
                extract_archive(str(archive), str(data_path))
        raw = datasets.CIFAR10(a.data, train=True, download=True)
        mean = torch.tensor(raw.data.mean(axis=0) / 255, dtype=torch.float32).permute(2, 0, 1)
        def subtract_mean(x):
            return x - mean
        ops = [transforms.ToTensor(), transforms.Lambda(subtract_mean)]
        if not a.no_augmentation:
            ops += [transforms.RandomCrop(32, padding=4), transforms.RandomHorizontalFlip()]
        train_data = datasets.CIFAR10(a.data, train=True, transform=transforms.Compose(ops))
        test_data = datasets.CIFAR10(a.data, train=False, download=True,
            transform=transforms.Compose([transforms.ToTensor(), transforms.Lambda(subtract_mean)]))
    provenance_file = Path(a.data) / 'archive_source.json'
    provenance = (json.loads(provenance_file.read_text()) if provenance_file.exists()
                  else {'url': datasets.CIFAR10.url, 'archive_md5': datasets.CIFAR10.tgz_md5})
    generator = torch.Generator().manual_seed(a.seed)
    train_loader = DataLoader(train_data, batch_size=a.batch_size, shuffle=True, num_workers=0, generator=generator)
    test_loader = DataLoader(test_data, batch_size=256, shuffle=False, num_workers=0)
    model = getattr(resnet, a.arch)().to(device)
    optimizer = torch.optim.SGD(model.parameters(), lr=0.1, momentum=0.9, weight_decay=1e-4)
    criterion = nn.CrossEntropyLoss()
    config = vars(a) | {'run_type': run_type, 'data_provenance': None if a.smoke else provenance, 'device_used': device, 'python': platform.python_version(), 'platform': platform.platform(),
        'torch': torch.__version__, 'torchvision': torchvision.__version__, 'numpy': np.__version__,
        'hardware': torch.cuda.get_device_name() if device == 'cuda' else platform.processor(),
        'upstream': upstream, 'parameters': sum(x.numel() for x in model.parameters()),
        'normalization': 'synthetic inputs' if a.smoke else 'per-pixel training mean subtraction', 'train_examples': len(train_data),
        'test_examples': len(test_data), 'metric_policy': 'final-step test error; no test-set checkpoint selection',
        'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'deterministic_algorithms': True, 'resume_supported': False}
    (out / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
    start = time.monotonic()
    eval_seconds = 0.0
    iterator = iter(train_loader)
    window_loss = window_correct = window_count = 0
    with (out / 'metrics.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['step', 'lr', 'train_loss', 'train_error_pct', 'test_loss', 'test_error_pct', 'seconds'])
        writer.writeheader()
        for step in range(1, a.steps + 1):
            # Steps 1..32000 use 0.1; 32001..48000 use 0.01; remaining use 0.001.
            lr = 0.1 * (0.1 ** (int(step > 32000) + int(step > 48000)))
            for group in optimizer.param_groups:
                group['lr'] = lr
            try:
                x, y = next(iterator)
            except StopIteration:
                iterator = iter(train_loader)
                x, y = next(iterator)
            model.train()
            x, y = x.to(device), y.to(device)
            optimizer.zero_grad(set_to_none=True)
            logits = model(x)
            loss = criterion(logits, y)
            if not torch.isfinite(loss):
                raise RuntimeError(f'Nonfinite loss at step {step}')
            loss.backward()
            optimizer.step()
            window_loss += loss.item() * len(y)
            window_correct += (logits.argmax(1) == y).sum().item()
            window_count += len(y)
            if step % a.eval_every == 0 or step == a.steps:
                evaluation_start = time.monotonic()
                model.eval()
                total_loss = correct = count = 0
                with torch.no_grad():
                    for tx, ty in test_loader:
                        tx, ty = tx.to(device), ty.to(device)
                        pred = model(tx)
                        total_loss += criterion(pred, ty).item() * len(ty)
                        correct += (pred.argmax(1) == ty).sum().item()
                        count += len(ty)
                eval_seconds += time.monotonic() - evaluation_start
                row = dict(step=step, lr=lr, train_loss=window_loss/window_count,
                    train_error_pct=100*(1-window_correct/window_count), test_loss=total_loss/count,
                    test_error_pct=100*(1-correct/count), seconds=time.monotonic()-start)
                writer.writerow(row)
                f.flush()
                print(json.dumps(row), flush=True)
                window_loss = window_correct = window_count = 0
        checkpoint_dir = Path('checkpoints') / out.name
        checkpoint_dir.mkdir(parents=True, exist_ok=True)
        torch.save({'model': model.state_dict(), 'optimizer': optimizer.state_dict(), 'step': a.steps, 'config': config}, checkpoint_dir/'final.pt')
    (out/'summary.json').write_text(json.dumps({'status': 'complete' if run_type == 'formal' else f'{run_type}_only',
        'seed': a.seed, 'final_step': a.steps, 'test_error_pct': row['test_error_pct'], 'seconds': row['seconds'],
        'training_seconds': row['seconds'] - eval_seconds, 'evaluation_seconds': eval_seconds}, indent=2)+'\n')

if __name__ == '__main__':
    main()
