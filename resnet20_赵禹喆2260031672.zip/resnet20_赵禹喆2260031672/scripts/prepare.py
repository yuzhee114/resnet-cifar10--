"""Fetch the course reference implementation and record its exact revision."""
import json
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]
target = root / 'vendor' / 'pytorch_resnet_cifar10'
if not (target / '.git').exists():
    target.parent.mkdir(parents=True, exist_ok=True)
    subprocess.run(['git', 'clone', 'https://github.com/akamaster/pytorch_resnet_cifar10.git', str(target)], check=True)
pinned = json.loads((root / 'upstream.json').read_text())['commit'] if (root / 'upstream.json').exists() else 'd5489e8995e81e91ce6b1d69dcc98ad579b0b153'
subprocess.run(['git', '-C', str(target), 'checkout', '--detach', pinned], check=True)
sha = subprocess.check_output(['git', '-C', str(target), 'rev-parse', 'HEAD'], text=True).strip()
record = root / 'upstream.json'
if record.exists() and json.loads(record.read_text())['commit'] != sha:
    raise SystemExit('Reference revision changed. Restore the commit in upstream.json before continuing.')
record.write_text(json.dumps({'repository': 'https://github.com/akamaster/pytorch_resnet_cifar10', 'commit': sha, 'modified_upstream_files': [], 'local_additions': ['train.py', 'summarize.py', 'scripts/prepare.py']}, indent=2) + '\n')
print('Reference pinned:', sha)
