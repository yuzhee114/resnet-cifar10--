"""Stage an existing CIFAR-10 archive only after matching torchvision's checksum."""
import argparse
import hashlib
import json
import shutil
from pathlib import Path

EXPECTED = 'c58f30108f718f92721af3b95e74349a'
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('archive', type=Path)
p.add_argument('--source', required=True, help='Download URL to record for provenance')
p.add_argument('--data', type=Path, default=Path('data'))
a = p.parse_args()
with a.archive.open('rb') as f:
    actual = hashlib.file_digest(f, 'md5').hexdigest()
if actual != EXPECTED:
    p.error(f'archive checksum mismatch ({actual}); no files copied')
a.data.mkdir(parents=True, exist_ok=True)
destination = a.data / 'cifar-10-python.tar.gz'
if a.archive.resolve() != destination.resolve():
    temporary = destination.with_suffix('.tmp')
    shutil.copyfile(a.archive, temporary)
    temporary.replace(destination)
(a.data / 'archive_source.json').write_text(json.dumps({'url': a.source, 'archive_md5': actual}, indent=2) + '\n')
print('Verified and staged CIFAR-10:', actual)
