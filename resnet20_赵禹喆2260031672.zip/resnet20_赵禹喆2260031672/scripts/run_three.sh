#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
python scripts/prepare.py
for seed in 0 1 2; do
  python -u train.py --seed "$seed" --device auto
done
python summarize.py
